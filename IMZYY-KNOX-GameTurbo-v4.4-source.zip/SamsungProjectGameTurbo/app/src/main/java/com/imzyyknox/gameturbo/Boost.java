package com.imzyyknox.gameturbo;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.ResolveInfo;
import java.io.File;

public class Boost {
    static ActivityManager.MemoryInfo mem(Context c) {
        ActivityManager.MemoryInfo m = new ActivityManager.MemoryInfo();
        ((ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE)).getMemoryInfo(m);
        return m;
    }
    static int killBg(Context c) {
        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        int n = 0;
        for (ResolveInfo r : c.getPackageManager().queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)) {
            String p = r.activityInfo.packageName;
            if (p.equals(c.getPackageName()) || (r.activityInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
            am.killBackgroundProcesses(p); n++;
        }
        return n;
    }
    static long size(File f) { if (!f.exists()) return 0; if (f.isFile()) return f.length(); long n = 0; File[] a = f.listFiles(); if (a != null) for (File x : a) n += size(x); return n; }
    static void wipe(File f, File keep) { if (!f.exists()) return; if (f.isDirectory()) { File[] a = f.listFiles(); if (a != null) for (File x : a) wipe(x, keep); } if (!f.equals(keep)) f.delete(); }
    /** mode 0 = RAM + cache, 1 = RAM only, 2 = cache only. Blocking: call off the UI thread. */
    static String run(Context c, int mode) {
        long before = mem(c).availMem; int n = mode < 2 ? killBg(c) : 0; long kb = 0;
        if (mode != 1) { kb = size(c.getCacheDir()) >> 10; wipe(c.getCacheDir(), c.getCacheDir()); }
        try { Thread.sleep(900); } catch (Exception ignored) { }
        long mb = Math.max(0, (mem(c).availMem - before) >> 20);
        return "✓ " + n + " app dirapikan • ~" + mb + " MB bebas • " + kb + " KB cache";
    }
}
