package com.imzyyknox.gameturbo;

import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.display.DisplayManager;
import android.provider.Settings;
import android.view.Choreographer;
import android.view.Display;
import android.view.WindowManager;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.TreeSet;

/** Real, non-root refresh-rate control. Games cannot be force-capped by a normal app; the display rate can. */
public class FpsEngine {
    static Display disp(Context c) { return ((DisplayManager) c.getSystemService(Context.DISPLAY_SERVICE)).getDisplay(Display.DEFAULT_DISPLAY); }

    /** Supported modes at the current resolution (avoids resolution switching). */
    static List<Display.Mode> modes(Context c) {
        Display d = disp(c); Display.Mode cur = d.getMode(); List<Display.Mode> out = new ArrayList<>();
        for (Display.Mode m : d.getSupportedModes())
            if (m.getPhysicalWidth() == cur.getPhysicalWidth() && m.getPhysicalHeight() == cur.getPhysicalHeight()) out.add(m);
        Collections.sort(out, (a, b) -> Float.compare(a.getRefreshRate(), b.getRefreshRate()));
        return out;
    }
    static List<Integer> rates(Context c) {
        TreeSet<Integer> s = new TreeSet<>();
        for (Display.Mode m : modes(c)) s.add(Math.round(m.getRefreshRate()));
        return new ArrayList<>(s);
    }
    static float current(Context c) { return disp(c).getRefreshRate(); }

    /** target 0 = MAX. Picks the lowest supported rate >= target, else the highest. */
    static int pick(Context c, int target) {
        List<Integer> r = rates(c);
        if (r.isEmpty()) return Math.round(current(c));
        if (target == 0) return r.get(r.size() - 1);
        for (int x : r) if (x >= target) return x;
        return r.get(r.size() - 1);
    }
    static void prefer(WindowManager.LayoutParams p, Context c, int hz) {
        for (Display.Mode m : modes(c)) if (Math.round(m.getRefreshRate()) == hz) { p.preferredDisplayModeId = m.getModeId(); break; }
        p.preferredRefreshRate = hz;
    }
    /** Needs "Modify system settings". Returns false if not granted. */
    static boolean apply(Context c, int hz) {
        if (!Settings.System.canWrite(c)) return false;
        ContentResolver cr = c.getContentResolver();
        SharedPreferences sp = c.getSharedPreferences("turbo", Context.MODE_PRIVATE);
        try {
            if (!sp.contains("pk0")) sp.edit().putFloat("pk0", Settings.System.getFloat(cr, "peak_refresh_rate", -1f)).putFloat("mn0", Settings.System.getFloat(cr, "min_refresh_rate", 0f)).apply();
            Settings.System.putFloat(cr, "peak_refresh_rate", hz);
            Settings.System.putFloat(cr, "min_refresh_rate", hz);
            return true;
        } catch (Exception e) { return false; }
    }
    static void reset(Context c) {
        if (!Settings.System.canWrite(c)) return;
        ContentResolver cr = c.getContentResolver();
        List<Integer> r = rates(c);
        try {
            Settings.System.putFloat(cr, "min_refresh_rate", 0f);
            Settings.System.putFloat(cr, "peak_refresh_rate", r.isEmpty() ? 60f : r.get(r.size() - 1));
        } catch (Exception ignored) { }
        c.getSharedPreferences("turbo", Context.MODE_PRIVATE).edit().putInt("fps", -1).apply();
    }
    /** Called ~1s after apply: reports what the display is really doing. */
    static String verify(Context c, int target, int hz) {
        int cur = Math.round(current(c));
        String note = (target > 0 && hz != target) ? (hz > target ? " (layar tidak punya " + target + " Hz, dipakai mode terendah)" : " (maks layar ini)") : "";
        if (cur == hz) return "✓ Layar berjalan " + cur + " Hz" + note;
        return "⚠ Diminta " + hz + " Hz, sistem masih " + cur + " Hz. Set juga 'Kehalusan gerakan' di Display";
    }

    /** Measures the real vsync rate delivered to the screen (live Hz). */
    static class Meter implements Choreographer.FrameCallback {
        private int n; private long t0; private boolean on; private TextView out;
        void start(TextView o) { out = o; n = 0; t0 = 0; on = true; Choreographer.getInstance().removeFrameCallback(this); Choreographer.getInstance().postFrameCallback(this); }
        void stop() { on = false; Choreographer.getInstance().removeFrameCallback(this); }
        @Override public void doFrame(long ns) {
            if (!on) return;
            if (t0 == 0) t0 = ns;
            n++;
            long d = ns - t0;
            if (d >= 1000000000L) { if (out != null) out.setText(Math.round(n * 1e9f / d) + " Hz"); n = 0; t0 = ns; }
            Choreographer.getInstance().postFrameCallback(this);
        }
    }
}
